# ClipScribe

Next.js (App Router) + TypeScript + Tailwind v4. No database, no auth, no payments.

## Local
```
cp .env.example .env.local   # fill in TRANSCRIPT_API_KEY / TRANSCRIPT_API_URL
npm install
npm run dev                  # http://localhost:3000
npm test                     # URL validator tests (Node 22.6+)
npm run typecheck && npm run build
```

## Deploy (Vercel)
Project Settings → Environment Variables → add `TRANSCRIPT_API_KEY` and `TRANSCRIPT_API_URL` (Production/Preview; do NOT use a NEXT_PUBLIC_ prefix). Redeploy.

## Status
`lib/provider.ts` is wired to TranscriptAPI.com per https://transcriptapi.com/docs/api (GET /youtube/transcript, Bearer auth). Parsing and error mapping are unit-tested against the documented schema; **a live request with a real key has not been tested yet.**
`lib/rateLimit.ts` is per-instance memory; use a shared store for multi-instance production.
Not yet added: CSP header (needs nonce setup), optional video metadata preview (provider supports `send_metadata=true`).

"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import { parseYouTubeUrl } from "@/lib/youtube";
import type { ApiResponse, Transcript } from "@/lib/types";

type Status = "idle" | "loading" | "error" | "done";
type Toast = { kind: "ok" | "err"; msg: string } | null;

const ts = (s: number) => {
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = Math.floor(s % 60);
  const pad = (n: number) => String(n).padStart(2, "0");
  return h ? `${h}:${pad(m)}:${pad(x)}` : `${m}:${pad(x)}`;
};

async function writeClipboard(text: string) {
  try {
    if (navigator.clipboard && window.isSecureContext) { await navigator.clipboard.writeText(text); return true; }
  } catch { /* fall through to legacy path */ }
  try {
    const ta = document.createElement("textarea");
    ta.value = text; ta.setAttribute("readonly", "");
    ta.style.cssText = "position:fixed;top:0;left:0;opacity:0";
    document.body.appendChild(ta); ta.select();
    const ok = document.execCommand("copy");
    ta.remove();
    return ok;
  } catch { return false; }
}

const btnPrimary = "rounded-lg bg-brand px-5 py-3 text-base font-semibold text-white transition-[background-color,transform] hover:bg-brand-hover active:scale-[.98] active:bg-brand-press disabled:cursor-not-allowed disabled:opacity-60";
const btnGhost = "rounded-lg border border-line bg-white px-3 py-2 text-sm font-medium transition-colors hover:bg-surface active:scale-[.98]";

export function Extractor() {
  const [url, setUrl] = useState("");
  const [invalid, setInvalid] = useState<string | null>(null);
  const [status, setStatus] = useState<Status>("idle");
  const [error, setError] = useState<{ message: string; retryable: boolean } | null>(null);
  const [data, setData] = useState<Transcript | null>(null);
  const [withTs, setWithTs] = useState(false);
  const [copied, setCopied] = useState(false);
  const [selText, setSelText] = useState("");
  const [toast, setToast] = useState<Toast>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const areaRef = useRef<HTMLDivElement>(null);
  const busy = useRef(false);
  const toastTimer = useRef<ReturnType<typeof setTimeout>>(undefined);

  const lines = useMemo(() => {
    if (!data) return [];
    if (withTs && data.timestampsAvailable)
      return data.segments.map((g) => (g.start != null ? `[${ts(g.start)}] ${g.text}` : g.text));
    return data.transcript.split("\n");
  }, [data, withTs]);
  const text = useMemo(() => lines.join("\n"), [lines]);
  const words = useMemo(() => (text.trim() ? text.trim().split(/\s+/).length : 0), [text]);

  useEffect(() => {
    const onSel = () => {
      const sel = window.getSelection(), area = areaRef.current;
      setSelText(sel && area && !sel.isCollapsed && area.contains(sel.anchorNode) && area.contains(sel.focusNode) ? sel.toString() : "");
    };
    document.addEventListener("selectionchange", onSel);
    return () => document.removeEventListener("selectionchange", onSel);
  }, []);

  const notify = (t: NonNullable<Toast>) => {
    setToast(t); clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 2500);
  };

  async function submit() {
    if (busy.current) return;
    if (!parseYouTubeUrl(url)) {
      setInvalid("Enter a valid YouTube link, such as youtube.com/watch?v=… or youtu.be/…");
      inputRef.current?.focus(); return;
    }
    busy.current = true; setInvalid(null); setError(null); setStatus("loading");
    const ac = new AbortController();
    const timer = setTimeout(() => ac.abort(), 40_000);
    try {
      const res = await fetch("/api/transcript", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url }), signal: ac.signal,
      });
      const json = (await res.json().catch(() => null)) as ApiResponse | null;
      if (!json) throw new Error("bad");
      if (!json.ok) { setError({ message: json.error.message, retryable: json.error.retryable }); setStatus("error"); return; }
      setData(json.data); setWithTs(false); setStatus("done");
    } catch (e) {
      const aborted = e instanceof DOMException && e.name === "AbortError";
      setError({ message: aborted ? "The request timed out. Try again." : "Couldn't reach ClipScribe. Check your connection and try again.", retryable: true });
      setStatus("error");
    } finally { clearTimeout(timer); busy.current = false; }
  }

  async function copy(value: string, okMsg: string, all = false) {
    const ok = await writeClipboard(value);
    notify(ok ? { kind: "ok", msg: okMsg } : { kind: "err", msg: "Copy failed. Select the text and copy it manually." });
    if (ok && all) { setCopied(true); setTimeout(() => setCopied(false), 1800); }
  }

  function reset() { setData(null); setStatus("idle"); setUrl(""); setError(null); setSelText(""); inputRef.current?.focus(); }

  return (
    <div id="extractor" className="mx-auto w-full max-w-2xl scroll-mt-24">
      <form onSubmit={(e) => { e.preventDefault(); submit(); }} noValidate className="rounded-2xl border border-line bg-white p-3 shadow-sm sm:p-4">
        <label htmlFor="yt-url" className="sr-only">YouTube video link</label>
        <div className="flex flex-col gap-3 sm:flex-row">
          <div className={`relative flex-1 rounded-lg border bg-white transition-colors focus-within:border-brand ${invalid ? "border-err" : "border-line"}`}>
            <svg className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-brand" width="22" height="22" viewBox="0 0 24 24" aria-hidden="true">
              <rect x="2" y="5" width="20" height="14" rx="4" fill="currentColor" /><path d="M10 9.5v5l4.5-2.5z" fill="#fff" />
            </svg>
            <input ref={inputRef} id="yt-url" type="url" inputMode="url" autoComplete="off" spellCheck={false}
              value={url} onChange={(e) => { setUrl(e.target.value); if (invalid) setInvalid(null); }}
              placeholder="Paste your YouTube video link here..." aria-invalid={!!invalid} aria-describedby={invalid ? "url-err" : undefined}
              className="h-12 w-full rounded-lg bg-transparent pl-11 pr-10 text-base outline-none placeholder:text-muted" />
            {url && (
              <button type="button" aria-label="Clear link" onClick={() => { setUrl(""); setInvalid(null); inputRef.current?.focus(); }}
                className="absolute right-1.5 top-1/2 -translate-y-1/2 rounded-md p-2 text-muted hover:text-ink">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18" /></svg>
              </button>
            )}
          </div>
          <button type="submit" disabled={status === "loading"} className={`${btnPrimary} h-12 py-0`}>
            {status === "loading" ? "Extracting…" : "Get Transcript"}
          </button>
        </div>
        {invalid && <p id="url-err" role="alert" className="mt-2 px-1 text-sm text-err">{invalid}</p>}
      </form>

      <div aria-live="polite" className="mt-4">
        {status === "loading" && (
          <div role="status" className="rise rounded-2xl border border-line bg-white p-6 text-center">
            <div className="mx-auto h-1 w-48 max-w-full overflow-hidden rounded-full bg-line"><div className="bar h-full w-1/3 rounded-full bg-brand" /></div>
            <p className="mt-4 font-medium">Extracting transcript...</p>
            <p className="mt-1 text-sm text-muted">This usually takes only a few moments.</p>
          </div>
        )}
        {status === "error" && error && (
          <div role="alert" className="rise rounded-2xl border border-err/30 bg-white p-5">
            <p className="font-medium text-err">Couldn&apos;t get the transcript</p>
            <p className="mt-1 text-sm text-muted">{error.message}</p>
            {error.retryable && <button type="button" onClick={submit} className={`${btnGhost} mt-3`}>Retry</button>}
          </div>
        )}
        {status === "done" && data && (
          <section aria-labelledby="t-h" className="rise rounded-2xl border border-line bg-white">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line p-4">
              <div>
                <h2 id="t-h" className="text-lg font-semibold">Transcript</h2>
                <p className="mt-0.5 flex items-center gap-1.5 text-sm text-ok">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M5 12l5 5L20 7" /></svg>
                  Transcript ready{data.language ? <span className="text-muted">, {data.language}</span> : null}
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                {data.timestampsAvailable && (
                  <div role="group" aria-label="Copy format" className="flex rounded-lg border border-line p-0.5 text-sm">
                    {([["Plain Text", false], ["With Timestamps", true]] as const).map(([l, v]) => (
                      <button key={l} type="button" aria-pressed={withTs === v} onClick={() => setWithTs(v)}
                        className={`rounded-md px-2.5 py-1.5 transition-colors ${withTs === v ? "bg-ink text-white" : "text-muted hover:text-ink"}`}>{l}</button>
                    ))}
                  </div>
                )}
                <button type="button" onClick={() => copy(text, "Transcript copied", true)} className={`${btnPrimary} px-4 py-2 text-sm`}>
                  {copied ? "Copied!" : "Copy Transcript"}
                </button>
              </div>
            </div>
            <div className="relative">
              <div ref={areaRef} tabIndex={0} role="region" aria-label="Transcript text" className="max-h-[26rem] overflow-y-auto whitespace-pre-wrap break-words p-4 text-[0.95rem] leading-7">
                {lines.map((l, i) => <div key={i} className="line">{l || "\u00A0"}</div>)}
              </div>
              {selText && (
                <button type="button" onMouseDown={(e) => e.preventDefault()} onClick={() => copy(selText, "Selection copied")}
                  className="rise absolute bottom-3 right-5 rounded-lg bg-ink px-3 py-2 text-sm font-medium text-white shadow-lg">Copy selection</button>
              )}
            </div>
            <div className="flex flex-wrap items-center justify-between gap-2 border-t border-line px-4 py-3 text-sm text-muted">
              <span>{words.toLocaleString()} words · {text.length.toLocaleString()} characters</span>
              <button type="button" onClick={reset} className="rounded-md px-2 py-1 hover:text-ink">Clear</button>
            </div>
          </section>
        )}
      </div>

      <div role="status" aria-live="polite" className="pointer-events-none fixed inset-x-0 bottom-5 z-50 flex justify-center px-4">
        <div className={`rounded-lg px-4 py-2.5 text-sm font-medium text-white shadow-lg transition-all duration-200 ${toast ? "translate-y-0 opacity-100" : "translate-y-2 opacity-0"} ${toast?.kind === "err" ? "bg-err" : "bg-ink"}`}>
          {toast?.msg ?? ""}
        </div>
      </div>
    </div>
  );
}

"use client";
import { useState } from "react";
import { Logo } from "./Logo";

const links = [["How it works", "/#how-it-works"], ["Features", "/#features"], ["FAQ", "/#faq"]];
const cta = "rounded-lg bg-brand px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-brand-hover active:bg-brand-press";

export function Nav() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-40 border-b border-line bg-white/95 backdrop-blur">
      <nav aria-label="Main" className="mx-auto flex h-16 max-w-5xl items-center justify-between px-4 sm:px-6">
        <Logo />
        <div className="hidden items-center gap-7 md:flex">
          {links.map(([l, h]) => <a key={h} href={h} className="rounded text-sm text-muted transition-colors hover:text-ink">{l}</a>)}
          <a href="/#extractor" className={cta}>Get started</a>
        </div>
        <button type="button" className="rounded-md p-2 md:hidden" aria-expanded={open} aria-controls="mobile-menu" aria-label={open ? "Close menu" : "Open menu"} onClick={() => setOpen(!open)}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
            {open ? <path d="M6 6l12 12M18 6L6 18" /> : <path d="M4 7h16M4 12h16M4 17h16" />}
          </svg>
        </button>
      </nav>
      <div id="mobile-menu" className={`grid transition-[grid-template-rows] duration-200 md:hidden ${open ? "grid-rows-[1fr]" : "grid-rows-[0fr]"}`}>
        <div className="overflow-hidden" inert={!open}>
          <div className="flex flex-col gap-1 border-t border-line px-4 py-3">
            {links.map(([l, h]) => <a key={h} href={h} onClick={() => setOpen(false)} className="rounded-md px-2 py-3 text-ink">{l}</a>)}
            <a href="/#extractor" onClick={() => setOpen(false)} className={`${cta} mt-1 text-center`}>Get started</a>
          </div>
        </div>
      </div>
    </header>
  );
}

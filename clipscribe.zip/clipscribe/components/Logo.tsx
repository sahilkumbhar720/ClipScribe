import Link from "next/link";
export function Logo({ className = "" }: { className?: string }) {
  return (
    <Link href="/" aria-label="ClipScribe home" className={`inline-flex items-center gap-2 rounded-md font-semibold tracking-tight ${className}`}>
      <svg width="28" height="28" viewBox="0 0 28 28" aria-hidden="true">
        <rect width="28" height="28" rx="7" fill="#FF0033" />
        <path d="M7 9h14M7 14h14M7 19h7" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" />
        <path d="M18 17.2v3.6l3.2-1.8z" fill="#fff" />
      </svg>
      <span className="text-[1.05rem]">ClipScribe</span>
    </Link>
  );
}

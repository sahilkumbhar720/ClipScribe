import { Nav } from "./Nav";
import { Footer } from "./Footer";
export function Legal({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <>
      <Nav />
      <main id="main" className="mx-auto max-w-2xl px-4 py-12 sm:px-6">
        <h1 className="text-3xl font-semibold tracking-tight">{title}</h1>
        <p className="mt-4 rounded-lg border border-line bg-surface p-3 text-sm text-muted">Template only. Items marked TODO must be completed and reviewed by a qualified professional before launch.</p>
        <div className="mt-6 space-y-4 leading-7 text-ink [&_h2]:mt-8 [&_h2]:text-lg [&_h2]:font-semibold">{children}</div>
      </main>
      <Footer />
    </>
  );
}

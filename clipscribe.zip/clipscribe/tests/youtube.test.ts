import { test } from "node:test";
import assert from "node:assert/strict";
import { parseYouTubeUrl as p } from "../lib/youtube.ts";

const ID = "dQw4w9WgXcQ";
test("accepts supported formats", () => {
  for (const u of [
    `https://www.youtube.com/watch?v=${ID}`, `https://youtube.com/watch?v=${ID}&t=42s&list=PL1`,
    `https://youtu.be/${ID}`, `https://youtu.be/${ID}?si=abc`, `https://www.youtube.com/shorts/${ID}`,
    `https://m.youtube.com/watch?v=${ID}`, `youtube.com/watch?v=${ID}`, `  https://youtu.be/${ID}  `,
  ]) assert.equal(p(u), ID, u);
});
test("rejects everything else", () => {
  for (const u of [
    "", "   ", "hello", `https://evil.com/watch?v=${ID}`, `https://youtube.com.evil.com/watch?v=${ID}`,
    `https://evil.com/?u=https://youtu.be/${ID}`, `https://youtu.be/short`, `https://www.youtube.com/watch`,
    `https://www.youtube.com/watch?v=${ID}extra`, `ftp://youtu.be/${ID}`, `javascript:alert(1)`,
    `https://user:pw@youtu.be/${ID}`, `http://localhost:3000/${ID}`, "https://youtu.be/" + "a".repeat(3000),
  ]) assert.equal(p(u), null, u);
  assert.equal(p(null), null); assert.equal(p(42), null);
});

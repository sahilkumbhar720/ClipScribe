import { test } from "node:test";
import assert from "node:assert/strict";
import { normalize, mapError, ProviderError } from "../lib/provider.ts";

// Shape copied from the documented example at https://transcriptapi.com/docs/api (schema fixture, not production data)
const doc = { video_id: "dQw4w9WgXcQ", language: "en", length_seconds: 213, lengthText: "3:33",
  transcript: [{ text: "Never gonna give you up", start: 0.0, duration: 4.12 }, { text: "Never gonna let you down", start: 4.12, duration: 3.85 }] };

test("normalizes documented JSON response without altering words", () => {
  const t = normalize(doc);
  assert.equal(t.transcript, "Never gonna give you up\nNever gonna let you down");
  assert.equal(t.segments.length, 2); assert.equal(t.segments[1].start, 4.12);
  assert.equal(t.language, "en"); assert.equal(t.timestampsAvailable, true);
});
test("no timestamps when segments lack start", () => {
  const t = normalize({ ...doc, transcript: [{ text: "a" }, { text: "b" }] });
  assert.equal(t.timestampsAvailable, false);
});
test("auto-generated language label", () => assert.equal(normalize({ ...doc, language: "asr-hi" }).language, "hi (auto-generated)"));
test("string transcript is passed through", () => assert.equal(normalize({ ...doc, transcript: "plain text" }).transcript, "plain text"));
test("rejects malformed and empty", () => {
  for (const b of [null, {}, { video_id: "x", transcript: 5 }, { video_id: "x", transcript: [{ nope: 1 }] }])
    assert.throws(() => normalize(b), (e) => e instanceof ProviderError && e.code === "malformed_response");
  assert.throws(() => normalize({ ...doc, transcript: [{ text: "  " }] }), (e) => e instanceof ProviderError && e.code === "empty_transcript");
});
test("maps documented errors", () => {
  assert.equal(mapError(404, "no_captions").code, "no_captions");
  assert.equal(mapError(404, "video_unavailable").code, "video_unavailable");
  assert.equal(mapError(429).retryable, true); assert.equal(mapError(503).retryable, true);
  assert.equal(mapError(401).status, 502); assert.equal(mapError(402).status, 503);
  assert.equal(mapError(422).status, 400);
  assert.ok(!mapError(401).userMessage.toLowerCase().includes("key"));
});

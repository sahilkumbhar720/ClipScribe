// In-memory, per server instance. Replace with a shared store (e.g. Redis/Upstash) when running multiple instances.
const hits = new Map<string, { n: number; reset: number }>();
const LIMIT = 10, WINDOW = 60_000;
export function rateLimit(key: string) {
  const now = Date.now();
  if (hits.size > 5000) for (const [k, v] of hits) if (v.reset < now) hits.delete(k);
  const h = hits.get(key);
  if (!h || h.reset < now) { hits.set(key, { n: 1, reset: now + WINDOW }); return { ok: true, retryAfter: 0 }; }
  h.n++;
  return h.n > LIMIT ? { ok: false, retryAfter: Math.ceil((h.reset - now) / 1000) } : { ok: true, retryAfter: 0 };
}

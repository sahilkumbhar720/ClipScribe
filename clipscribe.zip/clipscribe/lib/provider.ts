import type { Segment, Transcript } from "./types.ts";

export class ProviderError extends Error {
  code: string; userMessage: string; status: number; retryable: boolean;
  constructor(code: string, userMessage: string, status: number, retryable = false) {
    super(code);
    this.code = code; this.userMessage = userMessage; this.status = status; this.retryable = retryable;
  }
}

// TranscriptAPI.com: GET {base}/youtube/transcript?video_url=…  with  Authorization: Bearer <key>
// Docs: https://transcriptapi.com/docs/api
const DEFAULT_BASE = "https://transcriptapi.com/api/v2";

const malformed = () => new ProviderError("malformed_response", "The transcript service returned an unexpected response.", 502, true);

/** Turns the provider's JSON into our internal shape without changing any wording. */
export function normalize(body: unknown): Transcript {
  const b = (body ?? {}) as { transcript?: unknown; language?: unknown; video_id?: unknown };
  if (typeof b.video_id !== "string" || !b.video_id) throw malformed();
  const raw = b.transcript;
  const segments: Segment[] = [];
  let text: string;
  if (Array.isArray(raw)) {
    for (const s of raw) {
      const seg = s as { text?: unknown; start?: unknown } | null;
      if (!seg || typeof seg.text !== "string") throw malformed();
      segments.push(typeof seg.start === "number" && Number.isFinite(seg.start) ? { text: seg.text, start: seg.start } : { text: seg.text });
    }
    text = segments.map((s) => s.text).join("\n");
  } else if (typeof raw === "string") {
    text = raw;
  } else throw malformed();
  if (!text.trim()) throw new ProviderError("empty_transcript", "This video's transcript is empty.", 404);
  const lang = typeof b.language === "string" && b.language ? b.language : null;
  return {
    videoId: b.video_id,
    transcript: text,
    segments,
    // "asr-xx" means auto-generated captions per the provider docs
    language: lang && lang.startsWith("asr-") ? `${lang.slice(4)} (auto-generated)` : lang,
    timestampsAvailable: segments.length > 0 && segments.every((s) => s.start !== undefined),
  };
}

/** Maps documented provider error statuses/codes to safe user-facing errors. */
export function mapError(status: number, code?: string): ProviderError {
  if (status === 404) {
    if (code === "no_captions") return new ProviderError("no_captions", "This video has no captions, so there's no transcript to extract.", 404);
    if (code === "video_unavailable") return new ProviderError("video_unavailable", "This video is private, deleted, or unavailable.", 404);
    return new ProviderError("not_found", "No transcript is available for this video.", 404);
  }
  if (status === 400 || status === 422) return new ProviderError("invalid_url", "Enter a valid YouTube video link.", 400);
  if (status === 429) return new ProviderError("rate_limited", "Too many requests. Try again in a minute.", 429, true);
  if (status === 408 || status === 503) return new ProviderError("unavailable", "The transcript service is busy. Try again in a few seconds.", 503, true);
  if (status === 401) return new ProviderError("provider_auth", "The transcript service is misconfigured. Please try again later.", 502);
  if (status === 402) return new ProviderError("provider_credits", "The transcript service is temporarily unavailable. Please try again later.", 503);
  return new ProviderError("provider_error", "The transcript service had a problem. Try again.", 502, true);
}

export async function fetchTranscript(videoId: string, signal: AbortSignal): Promise<Transcript> {
  const key = process.env.TRANSCRIPT_API_KEY;
  if (!key) throw new ProviderError("not_configured", "The transcript service isn't configured yet.", 503);
  const base = (process.env.TRANSCRIPT_API_URL || DEFAULT_BASE).replace(/\/+$/, "");

  // Only the validated 11-char video ID is sent, never a user-supplied URL (SSRF-safe).
  const url = new URL(`${base}/youtube/transcript`);
  url.searchParams.set("video_url", videoId);
  url.searchParams.set("format", "json");
  url.searchParams.set("include_timestamp", "true");

  let res: Response;
  try {
    res = await fetch(url, { headers: { Authorization: `Bearer ${key}`, Accept: "application/json" }, signal, redirect: "error", cache: "no-store" });
  } catch (e) {
    if (signal.aborted) throw e; // route turns this into a timeout message
    throw new ProviderError("network", "Couldn't reach the transcript service. Try again.", 502, true);
  }

  const body: unknown = await res.json().catch(() => null);
  if (!res.ok) {
    const code = typeof (body as { code?: unknown } | null)?.code === "string" ? (body as { code: string }).code : undefined;
    console.error("transcript provider status:", res.status, code ?? ""); // never log headers or key
    throw mapError(res.status, code);
  }
  return normalize(body);
}

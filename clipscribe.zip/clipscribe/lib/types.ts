export type Segment = { text: string; start?: number }; // start in seconds, only if provider supplies it
export type Transcript = {
  videoId: string;
  transcript: string;
  segments: Segment[];
  language: string | null;
  timestampsAvailable: boolean;
};
export type ApiResponse =
  | { ok: true; data: Transcript }
  | { ok: false; error: { code: string; message: string; retryable: boolean } };

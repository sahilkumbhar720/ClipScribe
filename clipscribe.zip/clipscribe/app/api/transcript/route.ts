import { NextResponse } from "next/server";
import { parseYouTubeUrl } from "@/lib/youtube";
import { fetchTranscript, ProviderError } from "@/lib/provider";
import { rateLimit } from "@/lib/rateLimit";

export const runtime = "nodejs";
export const maxDuration = 30;

const fail = (code: string, message: string, status: number, retryable = false, headers?: Record<string, string>) =>
  NextResponse.json({ ok: false, error: { code, message, retryable } }, { status, headers });

export async function POST(req: Request) {
  const ip = (req.headers.get("x-forwarded-for") ?? "unknown").split(",")[0].trim();
  const rl = rateLimit(ip);
  if (!rl.ok) return fail("rate_limited", "Too many requests. Try again in a minute.", 429, true, { "Retry-After": String(rl.retryAfter) });

  const text = await req.text().catch(() => "");
  if (text.length > 4096) return fail("too_large", "Request too large.", 413);
  let body: unknown;
  try { body = JSON.parse(text); } catch { return fail("bad_request", "Invalid request.", 400); }

  const videoId = parseYouTubeUrl((body as { url?: unknown } | null)?.url);
  if (!videoId) return fail("invalid_url", "Enter a valid YouTube video link.", 400);

  try {
    const data = await fetchTranscript(videoId, AbortSignal.timeout(25_000));
    return NextResponse.json({ ok: true, data }, { headers: { "Cache-Control": "no-store" } });
  } catch (e) {
    if (e instanceof ProviderError) return fail(e.code, e.userMessage, e.status, e.retryable);
    if (e instanceof Error && e.name === "TimeoutError") return fail("timeout", "The transcript service took too long. Try again.", 504, true);
    console.error("transcript route error:", e instanceof Error ? e.name : "unknown");
    return fail("server_error", "Something went wrong on our side. Try again.", 500, true);
  }
}

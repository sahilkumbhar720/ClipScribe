import { Legal } from "@/components/Legal";
export const metadata = { title: "Privacy Policy · ClipScribe" };
export default function Page() {
  return (
    <Legal title="Privacy Policy">
      <p>Last updated: TODO (date).</p>
      <h2>What we process</h2>
      <p>The YouTube link you submit is sent to our server and to our transcript provider (TODO: name the provider) to retrieve the transcript. The transcript is returned to your browser and is not stored by ClipScribe in this version. TODO: confirm once the provider integration is final, including any provider-side logging.</p>
      <h2>Technical data</h2>
      <p>Your IP address is used for rate limiting and abuse prevention. TODO: state retention period for server logs.</p>
      <h2>Cookies and tracking</h2>
      <p>This version includes no analytics or advertising trackers. TODO: update if that changes.</p>
      <h2>Your rights and contact</h2>
      <p>TODO: add controller identity, applicable rights (e.g. GDPR/CCPA), and a contact address.</p>
    </Legal>
  );
}

import { Legal } from "@/components/Legal";
export const metadata = { title: "Terms of Service · ClipScribe" };
export default function Page() {
  return (
    <Legal title="Terms of Service">
      <p>Last updated: TODO (date).</p>
      <h2>The service</h2>
      <p>ClipScribe retrieves transcripts that are available for supported YouTube videos. Availability is not guaranteed, and some videos cannot be processed.</p>
      <h2>Your responsibilities</h2>
      <p>You are responsible for ensuring you have the right to use any transcript you retrieve. TODO: add acceptable-use rules and copyright/DMCA terms.</p>
      <h2>Limits and changes</h2>
      <p>TODO: define usage limits, any future paid plans, warranties and liability limits, governing law, and the operating legal entity.</p>
    </Legal>
  );
}

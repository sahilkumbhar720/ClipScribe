import { Nav } from "@/components/Nav";
import { Footer } from "@/components/Footer";
import { Extractor } from "@/components/Extractor";

const Icon = ({ d }: { d: string }) => (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={d} /></svg>
);
const steps = [
  ["Paste a link", "Copy the URL of a supported YouTube video and paste it into ClipScribe.", "M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"],
  ["Extract the transcript", "Our backend requests the available transcript from the configured provider.", "M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8zM14 3v5h5M9 13h6M9 17h6"],
  ["Copy your text", "Copy the complete transcript or select the exact text you need.", "M9 9h11v12H9zM5 15V3h11"],
];
const features = [
  ["Fast extraction", "Retrieve available transcripts through the configured API."],
  ["One-click copy", "Copy the complete transcript instantly."],
  ["Selective copying", "Select and copy specific portions of the transcript."],
  ["Timestamp support", "Preserve available timestamps when supplied by the provider."],
  ["Simple interface", "Get from a video URL to readable text without unnecessary steps."],
  ["Responsive design", "Use ClipScribe comfortably on desktop, tablet, and mobile."],
];
const faqs = [
  ["What is ClipScribe?", "ClipScribe helps you retrieve available transcripts from supported YouTube videos and copy the resulting text."],
  ["How do I extract a transcript?", "Paste a supported YouTube URL into the input field and click Get Transcript."],
  ["Can I copy the entire transcript?", "Yes. Use the Copy Transcript button to copy the complete available transcript."],
  ["Can I copy only part of a transcript?", "Yes. Select the text you need and use the available copy action or your device's normal text-selection controls."],
  ["Why is a transcript sometimes unavailable?", "A transcript may be unavailable because captions are missing, access is restricted, the provider does not support the video, or the service encounters an error."],
  ["Does ClipScribe change the transcript?", "No. ClipScribe preserves the returned transcript's wording and sequence rather than summarizing or rewriting it."],
  ["Is ClipScribe free?", "The initial version is intended to offer free transcript extraction. Actual usage limits, API costs, and future paid plans depend on the implemented configuration."],
];

export default function Home() {
  return (
    <>
      <Nav />
      <main id="main">
        <section className="mx-auto max-w-5xl px-4 pb-14 pt-10 sm:px-6 sm:pt-14">
          <div className="mx-auto max-w-2xl text-center">
            <p className="mx-auto inline-block rounded-full border border-line bg-surface px-3 py-1 text-xs font-semibold tracking-wide text-muted">THE SIMPLE WAY TO GET VIDEO TEXT</p>
            <h1 className="mt-5 text-balance text-4xl font-bold tracking-tight sm:text-6xl">Every Video. Every Word.</h1>
            <p className="mx-auto mt-4 mb-8 max-w-xl text-pretty text-lg text-muted">Extract YouTube transcripts in seconds. Paste a link, get the text, and copy it wherever you need it.</p>
          </div>
          <Extractor />
        </section>

        <section id="how-it-works" className="scroll-mt-20 border-t border-line bg-surface py-14">
          <div className="mx-auto max-w-5xl px-4 sm:px-6">
            <h2 className="text-2xl font-semibold tracking-tight">How it works</h2>
            <ol className="mt-8 grid gap-8 sm:grid-cols-3">
              {steps.map(([t, d, p]) => (
                <li key={t}>
                  <span className="grid h-10 w-10 place-items-center rounded-lg bg-white text-brand ring-1 ring-line"><Icon d={p} /></span>
                  <h3 className="mt-4 font-semibold">{t}</h3>
                  <p className="mt-1 text-sm leading-6 text-muted">{d}</p>
                </li>
              ))}
            </ol>
          </div>
        </section>

        <section id="features" className="scroll-mt-20 py-14">
          <div className="mx-auto max-w-5xl px-4 sm:px-6">
            <h2 className="text-2xl font-semibold tracking-tight">Features</h2>
            <dl className="mt-8 grid gap-x-10 sm:grid-cols-2 lg:grid-cols-3">
              {features.map(([t, d]) => (
                <div key={t} className="border-t border-line py-5">
                  <dt className="font-semibold">{t}</dt>
                  <dd className="mt-1 text-sm leading-6 text-muted">{d}</dd>
                </div>
              ))}
            </dl>
          </div>
        </section>

        <section id="faq" className="scroll-mt-20 border-t border-line bg-surface py-14">
          <div className="mx-auto max-w-2xl px-4 sm:px-6">
            <h2 className="text-2xl font-semibold tracking-tight">FAQ</h2>
            <div className="mt-6 divide-y divide-line border-y border-line">
              {faqs.map(([q, a]) => (
                <details key={q} className="group py-4">
                  <summary className="flex cursor-pointer items-center justify-between gap-4 rounded font-medium">
                    {q}
                    <svg className="chev shrink-0 text-muted transition-transform duration-200" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true"><path d="M6 9l6 6 6-6" /></svg>
                  </summary>
                  <p className="mt-2 text-sm leading-6 text-muted">{a}</p>
                </details>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}

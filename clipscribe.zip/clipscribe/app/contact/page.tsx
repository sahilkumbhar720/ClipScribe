import { Legal } from "@/components/Legal";
export const metadata = { title: "Contact · ClipScribe" };
export default function Page() {
  const email = process.env.NEXT_PUBLIC_CONTACT_EMAIL;
  return (
    <Legal title="Contact">
      {email ? <p>Email us at <a className="text-brand underline" href={`mailto:${email}`}>{email}</a>.</p>
             : <p>TODO: set NEXT_PUBLIC_CONTACT_EMAIL to publish a contact address.</p>}
    </Legal>
  );
}
